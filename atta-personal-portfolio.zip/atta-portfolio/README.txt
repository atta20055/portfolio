Attaurrahman Noorzad — Personal Portfolio

1. Keep your current atta20055.github.io repository unchanged.
2. On GitHub, create a new PUBLIC repository named "portfolio".
3. Upload index.html, style.css and app.js from this folder into its root.
4. Open repository Settings > Pages > Deploy from a branch > main > /(root) > Save.
5. Visit https://atta20055.github.io/portfolio/ after publishing.
6. OPTIONAL: Add a reviewed PDF called resume.pdf to enable the Download Resume button.

Please review all text and achievements before publishing.
